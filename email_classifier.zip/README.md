# Akaike Email Classifier

## Setup

```bash
git clone <repo_url>
cd email_classifier
python -m venv env
source env/bin/activate  # or `env\Scripts\activate` on Windows
pip install -r requirements.txt
